import json

def handler(event, context):
    for record in event['Records']:
        body = record['body']
        print(f"Processando comando: {body}")
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Comando processado com sucesso!"})
    }
